MONAD AFRICA HANDBOOK

This folder is ready for static hosting.
The main file is index.html.

For a permanent public URL, publish this folder with GitHub Pages or another static hosting provider.
